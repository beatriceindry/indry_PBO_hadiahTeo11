/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiahteori11;
import java.awt.*;
/**
 *
 * @author Asus
 */
public class HadiahTeori11 extends Panel{

    /**
     * @param args the command line arguments
     */
    HadiahTeori11() {
        setBackground(Color.GRAY);
    }
    
    public void paint(Graphics g){
        //rambut
        g.setColor(Color.blue);
        g.drawOval(160,10,200,250);
        g.fillOval(160,10,200,250);
        //kepala
        g.setColor(Color.green);
        g.drawOval(200,8,120,120);
        g.fillOval(200,8,120,120);
        // mata
        g.setColor(Color.BLACK);
        g.drawOval(235,50,10,8);
        g.fillOval(235,50,10,8);
        g.setColor(Color.BLACK);
        g.drawOval(280,50,10,8);
        g.fillOval(280,50,10,8);
        //mulut
        g.setColor(Color.BLACK);
        g.drawArc(250,70,20,20,3,-170);
        //badan
        g.drawLine(100,170,400,170);
        g.drawLine(255,130,255,400);
        g.drawLine(255, 400, 100, 500);
        g.drawLine(255, 400, 400, 500);
            }
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Testing Graphics Panel");
        HadiahTeori11 gp = new HadiahTeori11();
        f.add(gp);
        f.setSize(600,600);
        f.setVisible(true);
    }
    
}
